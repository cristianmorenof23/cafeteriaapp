import Head from 'next/head'
import Image from 'next/image'
import Layout from './layout/Layout'
import useCafeteria from '../../hooks/useCafeteria'



export default function Home() {

    const {categoriaActual} = useCafeteria()

    return (
        <Layout pagina={`Menu ${categoriaActual.nombre}`}>
            
        </Layout>
    )
}
