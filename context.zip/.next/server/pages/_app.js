/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./context/CafeteriaProvider.jsx":
/*!***************************************!*\
  !*** ./context/CafeteriaProvider.jsx ***!
  \***************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"CafeteriaProvider\": () => (/* binding */ CafeteriaProvider),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! axios */ \"axios\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_2__]);\naxios__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\nconst CafeteriaContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)();\nconst CafeteriaProvider = ({ children  })=>{\n    const [categorias, setCategorias] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);\n    const [categoriaActual, setCategoriaActual] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});\n    const obtenerCategorias = async ()=>{\n        const { data  } = await (0,axios__WEBPACK_IMPORTED_MODULE_2__[\"default\"])(\"/api/categorias\");\n        setCategorias(data);\n    };\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        obtenerCategorias();\n    }, []);\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        setCategoriaActual(categorias[0]);\n    }, [\n        categorias\n    ]);\n    const handleClickCategoria = (id)=>{\n        const categoria = categorias.filter((cat)=>cat.id === id);\n        setCategoriaActual(categoria[0]);\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(CafeteriaContext.Provider, {\n        value: {\n            categorias,\n            categoriaActual,\n            handleClickCategoria\n        },\n        children: children\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\crist\\\\OneDrive\\\\Escritorio\\\\restauranteapp\\\\context\\\\CafeteriaProvider.jsx\",\n        lineNumber: 29,\n        columnNumber: 9\n    }, undefined);\n};\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CafeteriaContext);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb250ZXh0L0NhZmV0ZXJpYVByb3ZpZGVyLmpzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUEyRDtBQUNqQztBQUUxQixNQUFNSSxpQ0FBbUJGLG9EQUFhQTtBQUV0QyxNQUFNRyxvQkFBb0IsQ0FBQyxFQUFDQyxTQUFRLEVBQUMsR0FBSztJQUN0QyxNQUFNLENBQUNDLFlBQVlDLGNBQWMsR0FBR1IsK0NBQVFBLENBQUMsRUFBRTtJQUMvQyxNQUFNLENBQUNTLGlCQUFpQkMsbUJBQW1CLEdBQUdWLCtDQUFRQSxDQUFDLENBQUM7SUFFeEQsTUFBTVcsb0JBQW9CLFVBQVk7UUFDbEMsTUFBTSxFQUFDQyxLQUFJLEVBQUMsR0FBRyxNQUFNVCxpREFBS0EsQ0FBQztRQUMzQkssY0FBY0k7SUFDbEI7SUFFQVgsZ0RBQVNBLENBQUMsSUFBTTtRQUNaVTtJQUNKLEdBQUcsRUFBRTtJQUVMVixnREFBU0EsQ0FBQyxJQUFNO1FBQ1pTLG1CQUFtQkgsVUFBVSxDQUFDLEVBQUU7SUFDcEMsR0FBRztRQUFDQTtLQUFXO0lBRWYsTUFBTU0sdUJBQXVCQyxDQUFBQSxLQUFNO1FBQy9CLE1BQU1DLFlBQVlSLFdBQVdTLE1BQU0sQ0FBQ0MsQ0FBQUEsTUFBT0EsSUFBSUgsRUFBRSxLQUFLQTtRQUN0REosbUJBQW1CSyxTQUFTLENBQUMsRUFBRTtJQUNuQztJQUVBLHFCQUNJLDhEQUFDWCxpQkFBaUJjLFFBQVE7UUFDdEJDLE9BQU87WUFDSFo7WUFDQUU7WUFDQUk7UUFDSjtrQkFFQ1A7Ozs7OztBQUdiO0FBSUM7QUFFRCxpRUFBZUYsZ0JBQWdCQSxFQUFBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcmVzdGF1cmFudGVhcHAvLi9jb250ZXh0L0NhZmV0ZXJpYVByb3ZpZGVyLmpzeD9mNzU0Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIGNyZWF0ZUNvbnRleHQgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xyXG5cclxuY29uc3QgQ2FmZXRlcmlhQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQoKVxyXG5cclxuY29uc3QgQ2FmZXRlcmlhUHJvdmlkZXIgPSAoe2NoaWxkcmVufSkgPT4ge1xyXG4gICAgY29uc3QgW2NhdGVnb3JpYXMsIHNldENhdGVnb3JpYXNdID0gdXNlU3RhdGUoW10pXHJcbiAgICBjb25zdCBbY2F0ZWdvcmlhQWN0dWFsLCBzZXRDYXRlZ29yaWFBY3R1YWxdID0gdXNlU3RhdGUoe30pXHJcblxyXG4gICAgY29uc3Qgb2J0ZW5lckNhdGVnb3JpYXMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgY29uc3Qge2RhdGF9ID0gYXdhaXQgYXhpb3MoJy9hcGkvY2F0ZWdvcmlhcycpXHJcbiAgICAgICAgc2V0Q2F0ZWdvcmlhcyhkYXRhKVxyXG4gICAgfVxyXG5cclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgb2J0ZW5lckNhdGVnb3JpYXMoKVxyXG4gICAgfSwgW10pXHJcblxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBzZXRDYXRlZ29yaWFBY3R1YWwoY2F0ZWdvcmlhc1swXSlcclxuICAgIH0sIFtjYXRlZ29yaWFzXSlcclxuXHJcbiAgICBjb25zdCBoYW5kbGVDbGlja0NhdGVnb3JpYSA9IGlkID0+IHtcclxuICAgICAgICBjb25zdCBjYXRlZ29yaWEgPSBjYXRlZ29yaWFzLmZpbHRlcihjYXQgPT4gY2F0LmlkID09PSBpZClcclxuICAgICAgICBzZXRDYXRlZ29yaWFBY3R1YWwoY2F0ZWdvcmlhWzBdKVxyXG4gICAgfVxyXG4gICAgXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxDYWZldGVyaWFDb250ZXh0LlByb3ZpZGVyXHJcbiAgICAgICAgICAgIHZhbHVlPXt7XHJcbiAgICAgICAgICAgICAgICBjYXRlZ29yaWFzLFxyXG4gICAgICAgICAgICAgICAgY2F0ZWdvcmlhQWN0dWFsLFxyXG4gICAgICAgICAgICAgICAgaGFuZGxlQ2xpY2tDYXRlZ29yaWFcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICAgIHtjaGlsZHJlbn1cclxuICAgICAgICA8L0NhZmV0ZXJpYUNvbnRleHQuUHJvdmlkZXI+XHJcbiAgICApXHJcbn1cclxuXHJcbmV4cG9ydCB7XHJcbiAgICBDYWZldGVyaWFQcm92aWRlclxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDYWZldGVyaWFDb250ZXh0Il0sIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwiY3JlYXRlQ29udGV4dCIsImF4aW9zIiwiQ2FmZXRlcmlhQ29udGV4dCIsIkNhZmV0ZXJpYVByb3ZpZGVyIiwiY2hpbGRyZW4iLCJjYXRlZ29yaWFzIiwic2V0Q2F0ZWdvcmlhcyIsImNhdGVnb3JpYUFjdHVhbCIsInNldENhdGVnb3JpYUFjdHVhbCIsIm9idGVuZXJDYXRlZ29yaWFzIiwiZGF0YSIsImhhbmRsZUNsaWNrQ2F0ZWdvcmlhIiwiaWQiLCJjYXRlZ29yaWEiLCJmaWx0ZXIiLCJjYXQiLCJQcm92aWRlciIsInZhbHVlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./context/CafeteriaProvider.jsx\n");

/***/ }),

/***/ "./src/pages/_app.js":
/*!***************************!*\
  !*** ./src/pages/_app.js ***!
  \***************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/styles/globals.css */ \"./src/styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _context_CafeteriaProvider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../context/CafeteriaProvider */ \"./context/CafeteriaProvider.jsx\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_CafeteriaProvider__WEBPACK_IMPORTED_MODULE_2__]);\n_context_CafeteriaProvider__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\nfunction App({ Component , pageProps  }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_context_CafeteriaProvider__WEBPACK_IMPORTED_MODULE_2__.CafeteriaProvider, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n            ...pageProps\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\crist\\\\OneDrive\\\\Escritorio\\\\restauranteapp\\\\src\\\\pages\\\\_app.js\",\n            lineNumber: 7,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\crist\\\\OneDrive\\\\Escritorio\\\\restauranteapp\\\\src\\\\pages\\\\_app.js\",\n        lineNumber: 6,\n        columnNumber: 5\n    }, this);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvX2FwcC5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQTZCO0FBQ3NDO0FBRXBELFNBQVNDLElBQUksRUFBRUMsVUFBUyxFQUFFQyxVQUFTLEVBQUUsRUFBRTtJQUNwRCxxQkFDRSw4REFBQ0gseUVBQWlCQTtrQkFDaEIsNEVBQUNFO1lBQVcsR0FBR0MsU0FBUzs7Ozs7Ozs7Ozs7QUFHOUIsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3Jlc3RhdXJhbnRlYXBwLy4vc3JjL3BhZ2VzL19hcHAuanM/OGZkYSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgJ0Avc3R5bGVzL2dsb2JhbHMuY3NzJ1xuaW1wb3J0IHsgQ2FmZXRlcmlhUHJvdmlkZXIgfSBmcm9tICcuLi8uLi9jb250ZXh0L0NhZmV0ZXJpYVByb3ZpZGVyJ1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcHAoeyBDb21wb25lbnQsIHBhZ2VQcm9wcyB9KSB7XG4gIHJldHVybiAoXG4gICAgPENhZmV0ZXJpYVByb3ZpZGVyPlxuICAgICAgPENvbXBvbmVudCB7Li4ucGFnZVByb3BzfSAvPlxuICAgIDwvQ2FmZXRlcmlhUHJvdmlkZXI+XG4gIClcbn1cbiJdLCJuYW1lcyI6WyJDYWZldGVyaWFQcm92aWRlciIsIkFwcCIsIkNvbXBvbmVudCIsInBhZ2VQcm9wcyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/pages/_app.js\n");

/***/ }),

/***/ "./src/styles/globals.css":
/*!********************************!*\
  !*** ./src/styles/globals.css ***!
  \********************************/
/***/ (() => {



/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./src/pages/_app.js"));
module.exports = __webpack_exports__;

})();